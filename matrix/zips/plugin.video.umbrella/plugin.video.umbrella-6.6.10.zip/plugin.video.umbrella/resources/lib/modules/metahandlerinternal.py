# -*- coding: utf-8 -*-
"""
	Umbrella Add-on (added 1/18/23)
"""

from resources.lib.modules import control
from sqlite3 import dbapi2 as db
import time

class MetaInternal:  
	'''
	This class performs all the handling of meta data, requesting, storing and sending back to calling application

		- Create cache DB if it does not exist
		- Get the meta data from TMDB/IMDB/TVDB
		- Store/Retrieve meta from cache DB
	'''
	def __init__(self, tmdb_api_key=None, omdb_api_key=None, tvdb_api_key=None):
		"""
        Initialize MetaData class

            :param tmdb_api_key=None: TMDB API key
            :param omdb_api_key=None: OMDB API Key
            :param tvdb_api_key=None: TVDB API Key
        """

		# Class variables
		self.tmdb_image_url = ''
		self.path = control.dataPath
		self.videocache = control.metaInternalCacheFile
		self.tmdb_api_key=tmdb_api_key
		self.omdb_api_key=omdb_api_key
		self.tvdb_api_key=tvdb_api_key
        
        # Check to make sure we have api keys set before continuing
		if not self.tmdb_api_key and not self.omdb_api_key and not self.tvdb_api_key:
			control.log('[ plugin.video.umbrella ] Internal MetaHandlers found no keys.', 1)

        # Initialize DB
		self.DB = MetaInternal.get_connection_videoMeta()

        # Check TMDB configuration, update if necessary
		self._set_tmdb_config()
        
	def get_connection():
		if not control.existsPath(control.dataPath): control.makeFile(control.dataPath)
		dbcon = db.connect(control.metaInternalCacheFile, timeout=60)
		dbcon.execute('''PRAGMA page_size = 32768''')
		dbcon.execute('''PRAGMA journal_mode = OFF''')
		dbcon.execute('''PRAGMA synchronous = OFF''')
		dbcon.execute('''PRAGMA temp_store = memory''')
		dbcon.execute('''PRAGMA mmap_size = 30000000000''')
		dbcon.row_factory = MetaInternal._dict_factory
		return dbcon

	def get_connection_cursor(dbcon):
		dbcur = dbcon.cursor()
		return dbcur

	def _dict_factory(cursor, row):
		d = {}
		for idx, col in enumerate(cursor.description): d[col[0]] = row[idx]
		return d

	def clear_video_meta():
		cleared = False
		try:
			dbcon = MetaInternal.get_connection()
			dbcur = dbcon.cursor()
			dbcur.execute('''DROP TABLE IF EXISTS episode_meta''')
			dbcur.execute('''VACUUM''')
			dbcur.connection.commit()
			cleared = True
		except:
			from resources.lib.modules import log_utils
			log_utils.error()
			cleared = False
		finally:
			dbcur.close() ; dbcon.close()
		return cleared

	def _set_tmdb_config(self):
		'''
		Query config database for required TMDB config values, set constants as needed
		Validate cache timestamp to ensure it is only refreshed once every 7 days
		'''

		control.log('Looking up TMDB config cache values')        
		tmdb_image_url = self._get_config('tmdb_image_url')
		tmdb_config_timestamp = self._get_config('tmdb_config_timestamp')
		
		#Grab current time in seconds            
		now = time.time()
		age = 0

		#Cache limit is 7 days, value needs to be in seconds: 60 seconds * 60 minutes * 24 hours * 7 days
		expire = 60 * 60 * 24 * 7
				
		#Check if image and timestamp values are valid
		if tmdb_image_url and tmdb_config_timestamp:
			created = float(tmdb_config_timestamp)
			age = now - created
			control.log('Cache age: %s , Expire: %s' % (age, expire))
			
			#If cache hasn't expired, set constant values
			if age <= float(expire):
				control.log('Cache still valid, setting values')
				control.log('Setting tmdb_image_url: %s' % tmdb_image_url)
				self.tmdb_image_url = tmdb_image_url
			else:
				control.log('Cache is too old, need to request new values')
		
		#Either we don't have the values or the cache has expired, so lets request and set them - update cache in the end
		if (not tmdb_image_url or not tmdb_config_timestamp) or age > expire:
			control.log('No cached config data found or cache expired, requesting from TMDB')

			tmdb = TMDB(tmdb_api_key=self.tmdb_api_key, omdb_api_key=self.omdb_api_key, lang='en')
			config_data = tmdb.call_config()

			if config_data:
				self.tmdb_image_url = config_data['images']['base_url']
				self._set_config('tmdb_image_url', config_data['images']['base_url'])
				self._set_config('tmdb_config_timestamp', now)
			else:
				self.tmdb_image_url = tmdb_image_url
    
	def _get_config(self, setting):
		'''
		Query local Config table for values
		'''
		
		#Query local table first for current values
		sql_select = "SELECT * FROM config where setting = '%s'" % setting

		control.log('Looking up in local cache for config data: %s' % setting)
		control.log('SQL Select: %s' % sql_select)        

		try:    
			matchedrow = self.DB.select_single(sql_select)
		except Exception as e:
			control.log('************* Error selecting from cache db: %s' % e)
			return None

		if matchedrow:
			control.log('Found config data in cache table for setting: %s value: %s' % (setting, dict(matchedrow)))
			return dict(matchedrow)['value']
		else:
			control.log('No match in local DB for config setting: %s' % setting)
			return None